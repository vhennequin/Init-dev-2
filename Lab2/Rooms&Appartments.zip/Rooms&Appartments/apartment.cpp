#include <iostream>
#include <string>
#include <stdexcept>
#include <vector>
#include "apartment.h"
#include "room.h"
using namespace std;

Apartment::Apartment(){
    cout << "empty constructor" << endl;
    _address = "1 rue Joliot-Curie 91400 Orsay";
    _zone = ZONE[0];
}

Apartment::Apartment(string address, vector<Room> rooms, int i){
    _address = address;
    _rooms = rooms;
    _zone = i;
}

void Apartment::display() const{
    cout << "The apartment is located at: " << _address << endl;
    cout << "it has " << nbRoom() << " rooms: " << endl;
    for (int i = 0; i < nbRoom(); i++){
        _rooms[i].display();
    }
    cout << "The zone is " << _zone << " with a price of " << ZONE[_zone] << " euros per square meter" << endl;
}

void Apartment::addRoom(const Room & newroom){
    _rooms.push_back(newroom);
    cout << "Successfully added to the apartment" << endl;
}

int Apartment::nbRoom() const{
    return _rooms.size();
}

float Apartment::area() const{
    float totalarea = 0;
    for (int i = 0; i < nbRoom(); i++){
        totalarea += _rooms[i].area();
    }
    return totalarea;
}

int Apartment::compare(const Apartment & app) const{
    int comparison;
    if (area() > app.area()) comparison = 1;
    else{
        if (area() == app.area()) comparison = 0;
        else comparison = -1;
    }
    return comparison;
}

float Apartment::value() const{
    return (ZONE[_zone] * area());
}

int Apartment::comparePrice(const Apartment & app) const{
    int comparison;
    if (value() > app.value()) comparison = 1;
    else{
        if (value() == app.value()) comparison = 0;
        else comparison = -1;
    }
    return comparison;
}
